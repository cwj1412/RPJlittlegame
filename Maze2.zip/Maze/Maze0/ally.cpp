#include "ally.h"
#include "iostream"
using namespace std;

void Ally::move(int direction, int steps){
    switch (direction){
        case 1:
            this->_pos_y -= steps;
            dir=1;
            break;
        case 2:
            this->_pos_y += steps;
            dir=2;
            break;
        case 3:
            this->_pos_x -= steps;
            dir=3;
            break;
        case 4:
            this->_pos_x += steps;
            dir=4;
            break;
    }
}
void Ally::show(QPainter * painter){
    int gSize = ICON::GRID_SIZE;
    if(dir==1) painter->drawImage(this->_pos_x*gSize,this->_pos_y*gSize,this->_up);
    else if(dir==2) painter->drawImage(this->_pos_x*gSize,this->_pos_y*gSize,this->_down);
    else if(dir==3) painter->drawImage(this->_pos_x*gSize,this->_pos_y*gSize,this->_left);
    else painter->drawImage(this->_pos_x*gSize,this->_pos_y*gSize,this->_right);
}
void Ally::initObj(string type){
    if(type=="Kiki"){
        this->_coverable = false;
        this->_eatable = false;
        this->_vulnerable=true;
        _up.load("C:/Users/jmzxc/Desktop/images/Kiki4.png");
        _down.load("C:/Users/jmzxc/Desktop/images/Kiki1.png");
        _left.load("C:/Users/jmzxc/Desktop/images/Kiki2.png");
        _right.load("C:/Users/jmzxc/Desktop/images/Kiki3.png");
    }
    else cout<<"cannot find this ally"<<endl;

}
