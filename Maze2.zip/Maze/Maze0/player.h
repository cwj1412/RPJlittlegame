#ifndef PLAYER_H
#define PLAYER_H
#include "rpgobj.h"
#include "ally.h"

class Player: public Ally
{
    int static dir;//记录人的朝向
public:
    Player(){HP=10;}
    ~Player(){}
    void initObj(string type);
};

#endif // PLAYER_H
