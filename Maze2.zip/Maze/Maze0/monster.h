#ifndef MONSTER_H
#define MONSTER_H
#include "wall.h"


class Monster: public Wall
{
public:
    Monster(int initialHP);
    Monster(){}
    ~Monster(){}
    int getHP() {return this->HP;}
    void updateHP(int num){this->HP+=num;}
private:
    int HP;//生命值

};

#endif // MONSTER_H
