#include "mw1.h"
#include "ui_mw1.h"
#include "icon.h"
#include <QTimer>
#include <fstream>
#include <map>
#include <iostream>

using namespace std;

MW1::MW1(QWidget *parent):
    QMainWindow(parent),
    ui(new Ui::MW1)
{
    ui->setupUi(this);

    //init game world
    initWorld("C:/Users/jmzxc/Desktop/maze_map.txt");//TODO 应该是输入有效的地图文件

    //以下是对时钟的初始化
    timer1 = new QTimer(this);
    connect(timer1,SIGNAL(timeout()),this,SLOT(randomMove()));//timeoutslot()为自定义槽
        //时钟事件与randomMove函数绑定
    timer1->start(100);
    timer1->setInterval(500);

    qsrand(QTime(0,0,0).secsTo(QTime::currentTime()));
        //设置随机数种子

    /*timer2 = new QTimer(this);
    connect(timer2,SIGNAL(timeout()),this,SLOT(randomCreate()));//timeoutslot()为自定义槽
        //时钟事件与randomMove函数绑定
    timer2->start(100);
    timer2->setInterval(1000);*/

    qsrand(QTime(0,0,0).secsTo(QTime::currentTime()));
}

MW1::~MW1()
{
    delete ui;
}

void MW1::paintEvent(QPaintEvent *){
    QPainter painter(this);
    QPixmap pix;
    pix.load("C:/Users/jmzxc/Desktop/images/background1.png");
    painter.drawPixmap(0,0,1200,750,pix);
    QPainter *pa;
    pa = new QPainter();
    pa->begin(this);
    this->showworld(pa);
    pa->end();
    delete pa;
}

void MW1::keyPressEvent(QKeyEvent *e)
{
    //direction = 1,2,3,4 for 上下左右
    if(e->key() == Qt::Key_A)
    {
        this->handlePlayerMove(3,1);
    }
    else if(e->key() == Qt::Key_D)
    {
        this->handlePlayerMove(4,1);
    }
    else if(e->key() == Qt::Key_W)
    {
        this->handlePlayerMove(1,1);
    }
    else if(e->key() == Qt::Key_S)
    {
         this->handlePlayerMove(2,1);
    }
    this->repaint();
}

void MW1::handleWallMove(int direction, int steps){
    vector<Wall>::iterator it;
    int px= 0;
    int py= 0;
    for(it=this->_walls.begin();it!=this->_walls.end();it++){
        px=(*it).getPosX();
        py=(*it).getPosY();
        //cout<<px<<" "<<py<<endl;
        direction= 1+(rand()+direction)%4;
        if(px>0&&px<=40&&py>0&&py<=35) (*it).move(direction, steps);
    }
}

void MW1::randomMove(){
    int d = 1 + rand()%4;
    this->handleWallMove(d,1);
    this->repaint();
}
/*void MW1::randomCreate(){
    int x = 2 + rand()%12;
    int y = 2 + (rand()*rand())%12;
    this->createThing(x,y);
    this->repaint();
}
*/
