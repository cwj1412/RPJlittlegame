#include "mw2.h"
#include "ui_mw2.h"

MW2::MW2(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MW2)
{
    ui->setupUi(this);
}

MW2::~MW2()
{
    delete ui;
}
