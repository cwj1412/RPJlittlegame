#include "player.h"
#include "iostream"
using namespace std;

int Player::dir=2;//初始时人面朝下
void Player::initObj(string type){
    if(type=="player"){
        this->_coverable = false;
        this->_eatable = false;
        this->_vulnerable=true;
        _up.load("C:/Users/jmzxc/Desktop/images/Thomas4.png");
        _down.load("C:/Users/jmzxc/Desktop/images/Thomas1.png");
        _left.load("C:/Users/jmzxc/Desktop/images/Thomas2.png");
        _right.load("C:/Users/jmzxc/Desktop/images/Thomas3.png");
    }
    else cout<<"cannot find player"<<endl;

}
