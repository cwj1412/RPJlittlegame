#include <QApplication>
#include <QPainter>
#include "mainmenu.h"
#include "grass.h"
#include "iostream"
using namespace std;
int main(int argc, char *argv[])
{
    QApplication a(argc,argv);
    //MainWindow w;//创建主界面
    mainmenu m;//创建对话框。
    grass s1;
    if(m.exec() == QDialog::Accepted){//当按钮“进入主界面”被按下则执行
        grass::step=1;
        s1.show();
        if(s1.exec() == QDialog::Accepted){
            grass::step=2;
            while(grass::step<17){
                if(s1.exec() == QDialog::Rejected){
                    a.lastWindowClosed();
                    cout<<"!!!"<<endl;
                    return 0;
                }
                else/*if(s1.exec() == QDialog::Accepted)*/ {
                   s1.repaint();
                   s1.show();
                   cout<<"????"<<endl;
                   cout<<grass::step<<endl;
                }
                grass::step++;
            }
        }

    }
    else return 0;//否则退出程序
    //return s1.exec();这是一个循环时间函数！！

}
