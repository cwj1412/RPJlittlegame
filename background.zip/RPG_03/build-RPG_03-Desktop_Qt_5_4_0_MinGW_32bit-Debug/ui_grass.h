/********************************************************************************
** Form generated from reading UI file 'grass.ui'
**
** Created by: Qt User Interface Compiler version 5.4.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_GRASS_H
#define UI_GRASS_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_grass
{
public:
    QPushButton *pushButton;
    QPushButton *pushButton_2;

    void setupUi(QDialog *grass)
    {
        if (grass->objectName().isEmpty())
            grass->setObjectName(QStringLiteral("grass"));
        grass->resize(1200, 750);
        pushButton = new QPushButton(grass);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(1010, 570, 161, 71));
        pushButton_2 = new QPushButton(grass);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(1010, 670, 161, 71));

        retranslateUi(grass);

        QMetaObject::connectSlotsByName(grass);
    } // setupUi

    void retranslateUi(QDialog *grass)
    {
        grass->setWindowTitle(QApplication::translate("grass", "Dialog", 0));
#ifndef QT_NO_WHATSTHIS
        pushButton->setWhatsThis(QApplication::translate("grass", "<html><head/><body><p><br/></p></body></html>", 0));
#endif // QT_NO_WHATSTHIS
        pushButton->setText(QApplication::translate("grass", "Next", 0));
        pushButton_2->setText(QApplication::translate("grass", "Close", 0));
    } // retranslateUi

};

namespace Ui {
    class grass: public Ui_grass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_GRASS_H
