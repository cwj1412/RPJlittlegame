/********************************************************************************
** Form generated from reading UI file 'mw4.ui'
**
** Created by: Qt User Interface Compiler version 5.4.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MW4_H
#define UI_MW4_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_MW4
{
public:
    QPushButton *pushButton;

    void setupUi(QDialog *MW4)
    {
        if (MW4->objectName().isEmpty())
            MW4->setObjectName(QStringLiteral("MW4"));
        MW4->resize(500, 750);
        pushButton = new QPushButton(MW4);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(360, 660, 111, 51));

        retranslateUi(MW4);

        QMetaObject::connectSlotsByName(MW4);
    } // setupUi

    void retranslateUi(QDialog *MW4)
    {
        MW4->setWindowTitle(QApplication::translate("MW4", "Dialog", 0));
        pushButton->setText(QApplication::translate("MW4", "About us", 0));
    } // retranslateUi

};

namespace Ui {
    class MW4: public Ui_MW4 {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MW4_H
