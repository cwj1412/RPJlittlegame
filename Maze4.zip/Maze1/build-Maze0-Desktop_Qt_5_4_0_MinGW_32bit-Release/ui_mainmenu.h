/********************************************************************************
** Form generated from reading UI file 'mainmenu.ui'
**
** Created by: Qt User Interface Compiler version 5.4.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINMENU_H
#define UI_MAINMENU_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_mainmenu
{
public:
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QPushButton *pushButton_3;

    void setupUi(QDialog *mainmenu)
    {
        if (mainmenu->objectName().isEmpty())
            mainmenu->setObjectName(QStringLiteral("mainmenu"));
        mainmenu->resize(500, 750);
        pushButton = new QPushButton(mainmenu);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(300, 70, 151, 71));
        pushButton_2 = new QPushButton(mainmenu);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(300, 170, 151, 71));
        pushButton_3 = new QPushButton(mainmenu);
        pushButton_3->setObjectName(QStringLiteral("pushButton_3"));
        pushButton_3->setGeometry(QRect(300, 270, 151, 71));

        retranslateUi(mainmenu);
        QObject::connect(pushButton_3, SIGNAL(clicked()), mainmenu, SLOT(close()));

        QMetaObject::connectSlotsByName(mainmenu);
    } // setupUi

    void retranslateUi(QDialog *mainmenu)
    {
        mainmenu->setWindowTitle(QApplication::translate("mainmenu", "Dialog", 0));
        pushButton->setText(QApplication::translate("mainmenu", "\346\270\270\346\210\217\350\257\264\346\230\216", 0));
        pushButton_2->setText(QApplication::translate("mainmenu", "\345\274\200\345\247\213\346\270\270\346\210\217", 0));
        pushButton_3->setText(QApplication::translate("mainmenu", "\351\200\200\345\207\272", 0));
    } // retranslateUi

};

namespace Ui {
    class mainmenu: public Ui_mainmenu {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINMENU_H
