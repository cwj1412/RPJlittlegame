#include "ally.h"
#include "iostream"
using namespace std;

void Ally::updateHP(int num){
    if(num<0) {
        QMediaPlayer * player = new QMediaPlayer;
        player->setMedia(QUrl::fromLocalFile("C:/Users/jmzxc/Desktop/images/phurt.mp3"));
        player->setVolume(30);
        player->play();
        if(DEF<=30) this->HP+=num;
        else if(DEF>30&&DEF<=50) this->HP+=num+2;
        else if(DEF>50&&DEF<=80) this->HP+=num+3;
        else this->HP+=num+4;
    }
    else this->HP+=num;
}

void Ally::move(int direction, int steps){
    switch (direction){
        case 1:
            this->_pos_y -= steps;
            dir=1;
            break;
        case 2:
            this->_pos_y += steps;
            dir=2;
            break;
        case 3:
            this->_pos_x -= steps;
            dir=3;
            break;
        case 4:
            this->_pos_x += steps;
            dir=4;
            break;
    }
}
void Ally::show(QPainter * painter){
    int gSize = ICON::GRID_SIZE;
    if(dir==1) painter->drawImage(this->_pos_x*gSize,this->_pos_y*gSize,this->_up);
    else if(dir==2) painter->drawImage(this->_pos_x*gSize,this->_pos_y*gSize,this->_down);
    else if(dir==3) painter->drawImage(this->_pos_x*gSize,this->_pos_y*gSize,this->_left);
    else painter->drawImage(this->_pos_x*gSize,this->_pos_y*gSize,this->_right);
}
void Ally::initObj(string type){
    QImage all;
    this->_icon = ICON::findICON(type);
    if(type=="Kiki"){
        this->_coverable = false;
        this->_eatable = false;
        this->_vulnerable=true;

        all.load("C:/Users/jmzxc/Desktop/images/Kiki4.png");
        this->_up = all.copy(QRect(_icon.getSrcX()*ICON::GRID_SIZE, _icon.getSrcY()*ICON::GRID_SIZE, _icon.getWidth()*ICON::GRID_SIZE, _icon.getHeight()*ICON::GRID_SIZE));
        all.load("C:/Users/jmzxc/Desktop/images/Kiki1.png");
        this->_down = all.copy(QRect(_icon.getSrcX()*ICON::GRID_SIZE, _icon.getSrcY()*ICON::GRID_SIZE, _icon.getWidth()*ICON::GRID_SIZE, _icon.getHeight()*ICON::GRID_SIZE));
        all.load("C:/Users/jmzxc/Desktop/images/Kiki2.png");
        this->_left = all.copy(QRect(_icon.getSrcX()*ICON::GRID_SIZE, _icon.getSrcY()*ICON::GRID_SIZE, _icon.getWidth()*ICON::GRID_SIZE, _icon.getHeight()*ICON::GRID_SIZE));
        all.load("C:/Users/jmzxc/Desktop/images/Kiki3.png");
        this->_right = all.copy(QRect(_icon.getSrcX()*ICON::GRID_SIZE, _icon.getSrcY()*ICON::GRID_SIZE, _icon.getWidth()*ICON::GRID_SIZE, _icon.getHeight()*ICON::GRID_SIZE));
    }
    else if(type=="Terasa"){
        this->_coverable = false;
        this->_eatable = false;
        this->_vulnerable=true;

        all.load("C:/Users/jmzxc/Desktop/images/Terasa4.png");
        this->_up = all.copy(QRect(_icon.getSrcX()*ICON::GRID_SIZE, _icon.getSrcY()*ICON::GRID_SIZE, _icon.getWidth()*ICON::GRID_SIZE, _icon.getHeight()*ICON::GRID_SIZE));
        all.load("C:/Users/jmzxc/Desktop/images/Terasa1.png");
        this->_down = all.copy(QRect(_icon.getSrcX()*ICON::GRID_SIZE, _icon.getSrcY()*ICON::GRID_SIZE, _icon.getWidth()*ICON::GRID_SIZE, _icon.getHeight()*ICON::GRID_SIZE));
        all.load("C:/Users/jmzxc/Desktop/images/Terasa2.png");
        this->_left = all.copy(QRect(_icon.getSrcX()*ICON::GRID_SIZE, _icon.getSrcY()*ICON::GRID_SIZE, _icon.getWidth()*ICON::GRID_SIZE, _icon.getHeight()*ICON::GRID_SIZE));
        all.load("C:/Users/jmzxc/Desktop/images/Terasa3.png");
        this->_right = all.copy(QRect(_icon.getSrcX()*ICON::GRID_SIZE, _icon.getSrcY()*ICON::GRID_SIZE, _icon.getWidth()*ICON::GRID_SIZE, _icon.getHeight()*ICON::GRID_SIZE));
    }
    else if(type=="Newt"){
        this->_coverable = false;
        this->_eatable = false;
        this->_vulnerable=true;

        all.load("C:/Users/jmzxc/Desktop/images/Newt4.png");
        this->_up = all.copy(QRect(_icon.getSrcX()*ICON::GRID_SIZE, _icon.getSrcY()*ICON::GRID_SIZE, _icon.getWidth()*ICON::GRID_SIZE, _icon.getHeight()*ICON::GRID_SIZE));
        all.load("C:/Users/jmzxc/Desktop/images/Newt1.png");
        this->_down = all.copy(QRect(_icon.getSrcX()*ICON::GRID_SIZE, _icon.getSrcY()*ICON::GRID_SIZE, _icon.getWidth()*ICON::GRID_SIZE, _icon.getHeight()*ICON::GRID_SIZE));
        all.load("C:/Users/jmzxc/Desktop/images/Newt2.png");
        this->_left = all.copy(QRect(_icon.getSrcX()*ICON::GRID_SIZE, _icon.getSrcY()*ICON::GRID_SIZE, _icon.getWidth()*ICON::GRID_SIZE, _icon.getHeight()*ICON::GRID_SIZE));
        all.load("C:/Users/jmzxc/Desktop/images/Newt3.png");
        this->_right = all.copy(QRect(_icon.getSrcX()*ICON::GRID_SIZE, _icon.getSrcY()*ICON::GRID_SIZE, _icon.getWidth()*ICON::GRID_SIZE, _icon.getHeight()*ICON::GRID_SIZE));
    }
    else if(type=="Minho"){
        this->_coverable = false;
        this->_eatable = false;
        this->_vulnerable=true;

        all.load("C:/Users/jmzxc/Desktop/images/Minho4.png");
        this->_up = all.copy(QRect(_icon.getSrcX()*ICON::GRID_SIZE, _icon.getSrcY()*ICON::GRID_SIZE, _icon.getWidth()*ICON::GRID_SIZE, _icon.getHeight()*ICON::GRID_SIZE));
        all.load("C:/Users/jmzxc/Desktop/images/Minho1.png");
        this->_down = all.copy(QRect(_icon.getSrcX()*ICON::GRID_SIZE, _icon.getSrcY()*ICON::GRID_SIZE, _icon.getWidth()*ICON::GRID_SIZE, _icon.getHeight()*ICON::GRID_SIZE));
        all.load("C:/Users/jmzxc/Desktop/images/Minho2.png");
        this->_left = all.copy(QRect(_icon.getSrcX()*ICON::GRID_SIZE, _icon.getSrcY()*ICON::GRID_SIZE, _icon.getWidth()*ICON::GRID_SIZE, _icon.getHeight()*ICON::GRID_SIZE));
        all.load("C:/Users/jmzxc/Desktop/images/Minho3.png");
        this->_right = all.copy(QRect(_icon.getSrcX()*ICON::GRID_SIZE, _icon.getSrcY()*ICON::GRID_SIZE, _icon.getWidth()*ICON::GRID_SIZE, _icon.getHeight()*ICON::GRID_SIZE));
    }
    else cout<<"cannot find this ally"<<endl;

}
