#include <monster.h>
Monster::Monster(int initialHP){
    HP=initialHP;
}

int Monster::getBulletX()
{
    return this->_bullets.getPosX();
}
int Monster::getBulletY()
{
    return this->_bullets.getPosY();
}


