#ifndef ALLY_H
#define ALLY_H
#include "rpgobj.h"
#include <QMediaPlayer>

class Ally: public RPGObj
{
public:
    Ally(){dir=2;}
    void move(int direction, int steps=1);
    //direction =1,2,3,4 for 上下左右
    void initObj(string type);
    void show(QPainter *painter);
    int getHP() {return this->HP;}
    int getEXP() {return this->EXP;}
    int getATK() {return this->ATK;}
    int getDEF() {return this->DEF;}

    void updateHP(int num);
    void updateEXP(int num){this->EXP+=num;}
    void updateATK(int num){this->ATK+=num;}
    void updateDEF(int num){this->DEF+=num;}

protected:
    int HP;//生命值
    int EXP;//经验值
    int ATK;//战斗值
    int DEF;//防御值
    int dir;//记录人的朝向
    QImage _up,_down,_left,_right;//人的四个方向图
};


#endif // ALLY_H
