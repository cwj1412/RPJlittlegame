#include <QApplication>
#include <QPainter>
#include "mainmenu.h"
#include "mw1.h"
#include "mw2.h"
#include "mw3.h"
#include "mw4.h"
#include "grass.h"
#include "load.h"
#include "iostream"

using namespace std;
int main(int argc, char *argv[])
{
    QApplication a(argc,argv);

    mainmenu m;//创建主界面
    grass s1;//创建对话框
    Load load;//读存档
    while(1){
        if(m.exec() == QDialog::Accepted){//当按钮“进入主界面”被按下则执行
            int level=load.Read("C:/Users/jmzxc/Desktop/level.txt");
            if(level==1){
                grass::step=1;
                s1.show();
                if(s1.exec() == QDialog::Accepted){
                    grass::step=2;//进入背景介绍
                    while(grass::step<18){
                        int rec=s1.exec();
                        if(rec == QDialog::Rejected){
                            a.lastWindowClosed();
                            return 0;
                        }
                        else if(rec == QDialog::Accepted) {//如果直接写exec()==Qdialog::Accepted,则默认打开了一次exec()
                           s1.repaint();
                           s1.show();
                           //ddcout<<grass::step<<endl;
                        }
                        grass::step++;
                    }
                    s1.close();
                }
            }
            while(1){
                MW1 mw1;
                if(mw1.exec() == QDialog::Accepted){
                    break;
                }
                mw1.close();

                if(World::gamelevel==1){
                    MW3 mw3;
                    mw3.exec();
                }
                else if(World::gamelevel==2){
                    MW2 mw2;
                    mw2.exec();
                }
                else{
                    MW4 mw4;
                    MW4::step=1;
                    if(mw4.exec()==QDialog::Accepted){
                        MW4::step=2;
                        mw4.exec();
                    }
                }
            }
        }
        else {
            return 0;//否则退出程序
            return a.exec();
        }
    }
}
