#ifndef MW1_H
#define MW1_H

#include <QDialog>
#include <QImage>
#include <QPainter>
#include<QKeyEvent>
#include "rpgobj.h"
#include "world.h"
#include <QCloseEvent>

namespace Ui {
class MW1;
}
//选关界面
class MW1 : public QDialog,public World
{
    Q_OBJECT

public:
    explicit MW1(QWidget *parent = 0);
    ~MW1();
    void initWorld(const char *mapFile);
    void showworld(QPainter * painter);
    void paintEvent(QPaintEvent *);
    void keyPressEvent(QKeyEvent *e);
    void chooselevel();

private slots:
    void on_pushButton_clicked();//exit键

private:
    Ui::MW1 *ui;
    vector<RPGObj> _enters;//每一关的入口
};

#endif // MW1_H


