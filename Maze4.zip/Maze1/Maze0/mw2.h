#ifndef MW2_H
#define MW2_H

#include <QDialog>
#include <QPainter>
#include <QKeyEvent>
#include <QTime>
#include <QTimer>
#include "rpgobj.h"
#include "bullet.h"
#include "world.h"

namespace Ui {
class MW2;
}
//蜘蛛怪界面
class MW2 : public QDialog, public World
{
    Q_OBJECT

public:
    explicit MW2(QWidget *parent = 0);
    ~MW2();
    void paintEvent(QPaintEvent *);
    void keyPressEvent(QKeyEvent *e);

    void handleMonsterMove(int direction, int steps);
    void ispass();//判断关卡是否通过


protected slots:
    void randomMove();//响应时钟事件的函数
    void handleBulletMove();
    void randomCreate();
private:
    Ui::MW2 *ui;
    QTimer *timer1;
    QTimer *timer2;
    QTimer *timer3;
    int MonsterShot;//记录spider被子弹集中次数
    static bool pass;
};

#endif // MW2_H
