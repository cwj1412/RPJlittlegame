#include "rpgobj.h"
#include <iostream>

void RPGObj::initObj(string type)
{
    //TODO 所支持的对象类型应定义为枚举
    if(type.compare("spider")==0)
    {
        this->_coverable=false;
        this->_eatable  =false;
        this->_vulnerable=true;
    }
    else if(type.compare("wall1")==0)
    {
        this->_coverable=false;
        this->_eatable  =false;
        this->_vulnerable=false;
    }
    else if(type.compare("wall2")==0)
    {
        this->_coverable=false;
        this->_eatable  =false;
        this->_vulnerable=false;
    }
    else if(type.compare("wall3")==0)
    {
        this->_coverable=false;
        this->_eatable  =false;
        this->_vulnerable=false;
    }
    else if(type.compare("wall4")==0)
    {
        this->_coverable=false;
        this->_eatable  =false;
        this->_vulnerable=false;
    }
    else if(type.compare("bullet")==0)
    {

        this->_coverable=false;
        this->_eatable  =false;
        this->_vulnerable=false;
    }
    else if(type.compare("bullet1")==0)
    {

        this->_coverable=false;
        this->_eatable  =false;
        this->_vulnerable=false;
    }
    else if(type.compare("bullet2")==0)
    {

        this->_coverable=false;
        this->_eatable  =false;
        this->_vulnerable=false;
    }
    else if(type.compare("bullet3")==0)
    {

        this->_coverable=false;
        this->_eatable  =false;
        this->_vulnerable=false;
    }
    else if(type.compare("bullet4")==0)
    {

        this->_coverable=false;
        this->_eatable  =false;
        this->_vulnerable=false;
    }
    else if(type.compare("skull1")==0)
    {

        this->_coverable=false;
        this->_eatable  =false;
        this->_vulnerable=false;
    }
    else if(type.compare("skull2")==0)
    {

        this->_coverable=false;
        this->_eatable  =false;
        this->_vulnerable=false;
    }
    else if(type.compare("fire1")==0)
    {

        this->_coverable=false;
        this->_eatable  =false;
        this->_vulnerable=false;
    }
    else if(type.compare("fire2")==0)
    {

        this->_coverable=false;
        this->_eatable  =false;
        this->_vulnerable=false;
    }

    else if(type.compare("enter")==0)
    {
        this->_coverable=true;
        this->_eatable  =false;
        this->_vulnerable=false;
    }
    else if(type.compare("final")==0)
    {
        this->_coverable=true;
        this->_eatable  =false;
        this->_vulnerable=false;
    }
    else if(type.compare("food1")==0)
    {

        this->_coverable=true;
        this->_eatable  =true;
        this->_vulnerable=false;
    }
    else if(type.compare("food2")==0)
    {

        this->_coverable=true;
        this->_eatable  =true;
        this->_vulnerable=false;
    }
    else if(type.compare("food3")==0)
    {

        this->_coverable=true;
        this->_eatable  =true;
        this->_vulnerable=false;
    }
    else if(type.compare("tool1")==0)
    {

        this->_coverable=true;
        this->_eatable  =true;
        this->_vulnerable=false;
    }
    else if(type.compare("tool2")==0)
    {

        this->_coverable=true;
        this->_eatable  =true;
        this->_vulnerable=false;
    }
    else
    {
        cout<<"invalid ICON type."<<type<<endl;
        return;
    }

    this->_icon = ICON::findICON(type);
    QImage all;

    //墙和怪物载入
    if(this->_icon.getTypeName()=="wall1")
    {
        all.load("C:/Users/jmzxc/Desktop/images/wall1.png");
    }
    else if(this->_icon.getTypeName()=="wall2")
    {
        all.load("C:/Users/jmzxc/Desktop/images/wall2.png");
    }
    else if(this->_icon.getTypeName()=="wall3")
    {
        all.load("C:/Users/jmzxc/Desktop/images/wall3.png");
    }
    else if(this->_icon.getTypeName()=="wall4")
    {
        all.load("C:/Users/jmzxc/Desktop/images/wall4.png");
    }
    else if(this->_icon.getTypeName()=="spider")
    {
        all.load("C:/Users/jmzxc/Desktop/images/spider1.png");
    }

    //Bullet类图片载入
    else if(this->_icon.getTypeName()=="bullet1")
    {
        all.load("C:/Users/jmzxc/Desktop/images/magic1_1.png");
    }
    else if(this->_icon.getTypeName()=="bullet2")
    {
        all.load("C:/Users/jmzxc/Desktop/images/magic0_1.png");
    }
    else if(this->_icon.getTypeName()=="bullet3")
    {
        all.load("C:/Users/jmzxc/Desktop/images/magic4_1.png");
    }
    else if(this->_icon.getTypeName()=="bullet4")
    {
        all.load("C:/Users/jmzxc/Desktop/images/magic5_1.png");
    }
    //MW2背景块载入
    else if(this->_icon.getTypeName()=="skull1")
    {
        all.load("C:/Users/jmzxc/Desktop/images/skull1.png");
    }
    else if(this->_icon.getTypeName()=="skull2")
    {
        all.load("C:/Users/jmzxc/Desktop/images/skull2.png");
    }
    else if(this->_icon.getTypeName()=="fire1")
    {
        all.load("C:/Users/jmzxc/Desktop/images/fire_1.png");
    }
    else if(this->_icon.getTypeName()=="fire2")
    {
        all.load("C:/Users/jmzxc/Desktop/images/fire_2.png");
    }

    //功能入口载入
    else if(this->_icon.getTypeName()=="enter")
    {
        all.load("C:/Users/jmzxc/Desktop/images/TileB.png");
    }
    else if(this->_icon.getTypeName()=="final")
    {
        all.load("C:/Users/jmzxc/Desktop/images/TileB.png");
    }

    //补给载入
    else if(this->_icon.getTypeName()=="food1")
    {
        all.load("C:/Users/jmzxc/Desktop/images/TileB.png");
    }
    else if(this->_icon.getTypeName()=="food2")
    {
        all.load("C:/Users/jmzxc/Desktop/images/TileB.png");
    }
    else if(this->_icon.getTypeName()=="food3")
    {
        all.load("C:/Users/jmzxc/Desktop/images/TileB.png");
    }
    else if(this->_icon.getTypeName()=="tool1")
    {
        all.load("C:/Users/jmzxc/Desktop/images/TileB.png");
    }
    else if(this->_icon.getTypeName()=="tool2")
    {
        all.load("C:/Users/jmzxc/Desktop/images/TileB.png");
    }

    this->_pic = all.copy(QRect(_icon.getSrcX()*ICON::GRID_SIZE, _icon.getSrcY()*ICON::GRID_SIZE, _icon.getWidth()*ICON::GRID_SIZE, _icon.getHeight()*ICON::GRID_SIZE));
}

void RPGObj::show(QPainter * pa){
    int gSize = ICON::GRID_SIZE;
    pa->drawImage(this->_pos_x*gSize,this->_pos_y*gSize,this->_pic);
}
void RPGObj::eatmusic() const{
    QMediaPlayer * player = new QMediaPlayer;
    player->setMedia(QUrl::fromLocalFile("C:/Users/jmzxc/Desktop/images/eatthing.mp3"));
    player->setVolume(30);
    player->play();
}

