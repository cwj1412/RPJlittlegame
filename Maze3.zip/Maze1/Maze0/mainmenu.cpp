#include "mainmenu.h"
#include "ui_mainmenu.h"
#include <QPainter>

mainmenu::mainmenu(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::mainmenu)
{
    ui->setupUi(this);
    setWindowTitle("menu");
}

mainmenu::~mainmenu()
{
    delete ui;
}

void mainmenu::paintEvent(QPaintEvent *) {
    QPainter painter(this);
    QPixmap pix;
    pix.load("C:/Users/jmzxc/Desktop/images/menu.jpg");
    painter.drawPixmap(0,0,500,750,pix);

}

void mainmenu::on_pushButton_2_clicked()
{
    accept();
}
