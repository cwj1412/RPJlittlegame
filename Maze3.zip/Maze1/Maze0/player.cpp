#include "player.h"
#include "iostream"
using namespace std;

Player::Player(){
    HP=50;
    DEF=30;
    ATK=20;
    _bulletsNum=10;
    canFire=1;
    dir=2;
}
void Player::initObj(string type){
    if(type=="player"){
        this->_coverable = false;
        this->_eatable = false;
        this->_vulnerable=true;

        QImage all;
        this->_icon = ICON::findICON(type);

        all.load("C:/Users/jmzxc/Desktop/images/Thomas4.png");
        this->_up = all.copy(QRect(_icon.getSrcX()*ICON::GRID_SIZE, _icon.getSrcY()*ICON::GRID_SIZE, _icon.getWidth()*ICON::GRID_SIZE, _icon.getHeight()*ICON::GRID_SIZE));
        all.load("C:/Users/jmzxc/Desktop/images/Thomas1.png");
        this->_down = all.copy(QRect(_icon.getSrcX()*ICON::GRID_SIZE, _icon.getSrcY()*ICON::GRID_SIZE, _icon.getWidth()*ICON::GRID_SIZE, _icon.getHeight()*ICON::GRID_SIZE));
        all.load("C:/Users/jmzxc/Desktop/images/Thomas2.png");
        this->_left = all.copy(QRect(_icon.getSrcX()*ICON::GRID_SIZE, _icon.getSrcY()*ICON::GRID_SIZE, _icon.getWidth()*ICON::GRID_SIZE, _icon.getHeight()*ICON::GRID_SIZE));
        all.load("C:/Users/jmzxc/Desktop/images/Thomas3.png");
        this->_right = all.copy(QRect(_icon.getSrcX()*ICON::GRID_SIZE, _icon.getSrcY()*ICON::GRID_SIZE, _icon.getWidth()*ICON::GRID_SIZE, _icon.getHeight()*ICON::GRID_SIZE));
    }
    else cout<<"cannot find player"<<endl;

}

void Player::Setbullet(int choice)
{
        if(choice==1)_bullets.initObj("bullet1");
        else if(choice==2)_bullets.initObj("bullet2");
        else if(choice==3)_bullets.initObj("bullet3");
        else if(choice==4)_bullets.initObj("bullet4");

        switch(this->getDir())
        {
        case 2:
            _bullets.setPosX(this->getPosX());
            _bullets.setPosY(this->getPosY()+1);
           break;

        case 1:
            _bullets.setPosX(this->getPosX());
            _bullets.setPosY(this->getPosY()-1);
            break;

        case 3:
            _bullets.setPosX(this->getPosX()-1);
            _bullets.setPosY(this->getPosY()+1);
            break;

        case 4:
            _bullets.setPosX(this->getPosX()+1);
            _bullets.setPosY(this->getPosY()+1);
            break;
        }
}

void Player::Fire()
{
     this->_bullets.move(this->getDir());
}

int Player::getBulletX()
{
    return this->_bullets.getPosX();
}
int Player::getBulletY()
{
    return this->_bullets.getPosY();
}


