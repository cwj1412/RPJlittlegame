#ifndef MONSTER_H
#define MONSTER_H
#include "wall.h"
#include "player.h"
#include "bullet.h"


class Monster: public Wall
{
public:
    Monster(int initialHP);
    Monster(){this->HP=100;this->canFire=1;}
    ~Monster(){}

    int getBulletX();
    int getBulletY();
    int getHP() {return this->HP;}
    bool getcanFire(){return canFire;}

    void updateHP(int num){this->HP+=num;}
    void DisappearBullet(bool a){this->_bullets.setifDisappear(a);}

    void Fire(int dir);
    void SetcanFire(bool choice){this->canFire=choice;}


private:
    int HP;//生命值
    Bullet _bullets;
    bool canFire;//是否能开火

    friend class World;
};

#endif // MONSTER_H
