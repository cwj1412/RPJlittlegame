#ifndef MW3_H
#define MW3_H

#include <QDialog>
#include <QImage>
#include <QPainter>
#include<QKeyEvent>
#include "rpgobj.h"
#include "world.h"
#include<QTime>
#include<QTimer>

namespace Ui {
class MW3;
}

class MW3 : public QDialog,public World
{
    Q_OBJECT

public:
    explicit MW3(QWidget *parent = 0);
    ~MW3();
    void paintEvent(QPaintEvent *);
    void keyPressEvent(QKeyEvent *e);
    void handleWallMove(int i, int direction, int steps);
    void ispass();

protected slots:
    void randomMove();//响应时钟事件的函数
    void randomCreate();

private:
    Ui::MW3 *ui;
    QTimer *timer1;//时钟，控制怪物移动频率
    QTimer *timer2;
    static bool pass;
};

#endif // MW3_H

