#ifndef PLAYER_H
#define PLAYER_H
#include "ally.h"
#include "bullet.h"

class Player: public Ally
{
public:
    friend class World;

    Player();
    ~Player(){}

    int getBulletX();
    int getBulletY();
    int getDir(){return dir;}
    bool getcanFire(){return canFire;}

    void Fire();
    void initObj(string type);
    void Setbullet(int choice);
    void setDir(int Ndir){dir=Ndir;}
    void DisappearBullet(bool a){this->_bullets.setifDisappear(a);}

protected:
    int _bulletsNum;
    bool canFire;//是否能开火
    Bullet _bullets;

};

#endif // PLAYER_H

