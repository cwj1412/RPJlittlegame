#include "load.h"
#include <iostream>
#include <fstream>
using namespace std;


int Load::Read(const char *filename)
{
    fstream file(filename);
    int newlevel;

    if(!file.is_open())
    {
        cout << "Error opening file"<<endl;
        exit (1);
    }
    while(!file.eof())
    {
        file>>newlevel;
    }
    file.close();
    return newlevel;
}
void Load::Save(const char *filename,int level)
{
    fstream file(filename);

    if(!file.is_open())
    {
        cout << "Error opening file"<<endl;
        exit (1);
    }
    else
    {
        file << level;  //存档 设置变量记录关数
    }
    file.close();
}
