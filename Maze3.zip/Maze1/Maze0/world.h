#ifndef WORLD_H
#define WORLD_H

#include "rpgobj.h"
#include <vector>
#include <string>
#include <QPainter>
#include <QMediaPlayer>
#include "player.h"
#include "monster.h"
#include "ally.h"
#include "wall.h"
#include "load.h"

class World
{

public:
    World(){}
    ~World(){}
     virtual void initWorld(const char *mapFile);
        //输入的文件中定义了初始状态下游戏世界有哪些对象，出生点在哪
        /*e.g.
           player5 5
           stone 3 3
           fruit 7 8
         */
    virtual void showworld(QPainter * painter);
        //显示游戏世界所有对象
    void handlePlayerMove(int direction, int steps);
    bool handlePlayerlive();
        //假定只有一个玩家

    virtual void handleMonsterMove(int direction, int steps);
    virtual void handleWallMove(int direction, int steps);
    virtual void ispass();
    static int playerlevel;//玩家通过的关卡数
    static int gamelevel;//当前游戏关卡

protected:
    static int hurtlevel;//怪兽的伤害点数
    static int curelevel;//补给品的补血点数
    static int attacklevel;//道具提高的攻击指数
    static int protectlevel;//道具提高的防御指数
    vector<RPGObj> _objs;//所有物品
    vector<Wall> _walls;//墙
    vector<Ally> _allys;//朋友们
    Player _player;//玩家
    Monster _monster;
    Monster _spider;
    RPGObj _fire1;
    RPGObj _fire2;
    RPGObj _fire3;
    RPGObj _fire4;
    RPGObj _final;//终点
};

#endif // WORLD_H
