#include "mw3.h"
#include "ui_mw3.h"
#include "icon.h"
#include "load.h"
#include <QTimer>
#include <fstream>
#include <map>
#include<QMessageBox>
#include <iostream>
using namespace std;

bool MW3::pass=false;//避免消息对话框递归重画

MW3::MW3(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::MW3)
{
    ui->setupUi(this);
    //init game world
    initWorld("C:/Users/jmzxc/Desktop/maze_map1.txt");//TODO 应该是输入有效的地图文件

    QMediaPlayer * player = new QMediaPlayer;
    player->setMedia(QUrl::fromLocalFile("C:/Users/jmzxc/Desktop/images/backgroundmusic3.mp3"));
    player->setVolume(30);
    player->play();

    //控制墙的随机移动,时钟事件与randomMove函数绑定
    timer1 = new QTimer(this);
    connect(timer1,SIGNAL(timeout()),this,SLOT(randomMove()));
    timer1->start(100);
    timer1->setInterval(1500);
    qsrand(QTime(0,0,0).secsTo(QTime::currentTime()));

    //控制产生补给,时钟事件与randomCreate函数绑定
    timer2 = new QTimer(this);
    connect(timer2,SIGNAL(timeout()),this,SLOT(randomCreate()));
    timer2->start(100);
    timer2->setInterval(3000);
    qsrand(QTime(0,0,0).secsTo(QTime::currentTime()));


}

MW3::~MW3()
{
    delete ui;
}

void MW3::paintEvent(QPaintEvent *){
    QPainter painter(this);
    QPixmap pix;
    pix.load("C:/Users/jmzxc/Desktop/images/background1.png");
    painter.drawPixmap(0,0,1200,750,pix);
    QPainter *pa;
    pa = new QPainter();
    pa->begin(this);
    this->showworld(pa);
    pa->end();
    delete pa;
    ispass();
}

void MW3::keyPressEvent(QKeyEvent *e)
{
    //direction = 1,2,3,4 for 上下左右
    if(e->key() == Qt::Key_A)
    {
        this->handlePlayerMove(3,1);
    }
    else if(e->key() == Qt::Key_D)
    {
        this->handlePlayerMove(4,1);
    }
    else if(e->key() == Qt::Key_W)
    {
        this->handlePlayerMove(1,1);
    }
    else if(e->key() == Qt::Key_S)
    {
         this->handlePlayerMove(2,1);
    }
    //cout<<_player.getPosX()<<" "<<_player.getPosY()<<endl;
    this->repaint();
}

void MW3::handleWallMove(int i,int direction, int steps){
    vector<RPGObj>::iterator ito;
    int px=_walls[i].getPosX();
    int py=_walls[i].getPosY();
    int pw=_walls[i].getWidth();
    int ph=_walls[i].getHeight();

    if(direction==1){
        for(ito=this->_objs.begin();ito!=this->_objs.end();ito++){
            if(px-(*ito).getPosX()<(*ito).getWidth()&&px>(*ito).getPosX()-pw&&py-(*ito).getHeight()==(*ito).getPosY()){
                if((*ito).canCover()==true){
                    this->move(direction, steps);
                }
            return;
            }
        }
        if(px-_player.getPosX()<_player.getWidth()&&px>_player.getPosX()-pw&&py-_player.getHeight()==_player.getPosY()){
            _player.updateHP(hurtlevel);
            cout<<"MW3:Dagerous!!!HP--!!Your HP:"<<_player.getHP()<<endl;
            return;
        }
    }
    else if(direction==2){
        for(ito=this->_objs.begin();ito!=this->_objs.end();ito++){
            if(px-(*ito).getPosX()<(*ito).getWidth()&&px>=(*ito).getPosX()-pw&&(*ito).getPosY()-ph+2==py){
                if((*ito).canCover()==true){
                    this->_monster.move(direction, steps);
                }
            return;
            }
        }
        if(px-_player.getPosX()<_player.getWidth()&&px>=_player.getPosX()-pw&&_player.getPosY()-ph+2==py){
            _player.updateHP(hurtlevel);
            cout<<"MW3:Dagerous!!!HP--!!Your HP:"<<_player.getHP()<<endl;
            return;
        }
    }
    else if(direction==3){
        for(ito=this->_objs.begin();ito!=this->_objs.end();ito++){
            if((*ito).getPosX()+(*ito).getWidth()==px&&(*ito).getPosY()<py+ph&&(*ito).getPosY()+(*ito).getHeight()>py){
                if((*ito).canCover()==true){
                    this->_monster.move(direction, steps);
                }
            return;
            }
        }
        if(_player.getPosX()+_player.getWidth()==px&&_player.getPosY()<py+ph-2&&_player.getPosY()+_player.getHeight()>py){
            _player.updateHP(hurtlevel);
            cout<<"MW3:Dagerous!!!HP--!!Your HP:"<<_player.getHP()<<endl;
            return;
        }
    }
    else if(direction==4){
        for(ito=this->_objs.begin();ito!=this->_objs.end();ito++){
            if((*ito).getPosX()-pw==px&&(*ito).getPosY()<py+ph&&(*ito).getPosY()+(*ito).getHeight()>py){
                if((*ito).canCover()==true){
                    this->_monster.move(direction, steps);
                }
            return;
            }
        }
        if(_player.getPosX()-pw==px&&_player.getPosY()<py+ph-2&&_player.getPosY()+_player.getHeight()>py){
            _player.updateHP(hurtlevel);
            cout<<"MW3:Dagerous!!!HP--!!Your HP:"<<_player.getHP()<<endl;
            return;
        }
    }
    _walls[i].move(direction, steps);
}

void MW3::randomMove(){
    int i;
    for(i=0;i<_walls.size();i++){
        int d = 1 + rand()%4;
        this->handleWallMove(i,d,1);
        this->repaint();
    }

}

void MW3::ispass(){
    if(_player.getPosX()==_final.getPosX()&&_player.getPosY()+2==_final.getPosY()&&_player.getHP()>=60){
        playerlevel=2;
        Load load;
        load.Save("C:/Users/jmzxc/Desktop/level.txt",playerlevel);

        if (pass==false){
            pass=true;
            QMessageBox::information(this, "Hint","YOU WIN!!!", QMessageBox::Ok);
            close();
        }

    }
}

void MW3::randomCreate(){
    int x = 2 + rand()%20;
    int y = 2 + (rand()*rand())%30;
    int n =rand()%5;
    string name;
    if(n==0) name="food1";
    else if(n==1) name="food2";
    else if(n==2) name="food3";
    else if(n==3) name="tool1";
    else if(n==4) name="tool2";

    RPGObj obj;
    obj.initObj(name);
    obj.setPosX(x);
    obj.setPosY(y);
    this->_objs.push_back(obj);
    this->repaint();
}

