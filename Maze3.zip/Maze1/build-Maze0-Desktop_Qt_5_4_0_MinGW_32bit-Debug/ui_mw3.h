/********************************************************************************
** Form generated from reading UI file 'mw3.ui'
**
** Created by: Qt User Interface Compiler version 5.4.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MW3_H
#define UI_MW3_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>

QT_BEGIN_NAMESPACE

class Ui_MW3
{
public:

    void setupUi(QDialog *MW3)
    {
        if (MW3->objectName().isEmpty())
            MW3->setObjectName(QStringLiteral("MW3"));
        MW3->resize(1200, 750);

        retranslateUi(MW3);

        QMetaObject::connectSlotsByName(MW3);
    } // setupUi

    void retranslateUi(QDialog *MW3)
    {
        MW3->setWindowTitle(QApplication::translate("MW3", "Dialog", 0));
    } // retranslateUi

};

namespace Ui {
    class MW3: public Ui_MW3 {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MW3_H
