#include "ally.h"

void Ally::move(int direction, int steps)//应规定好行驶路线？？？文件？？
{
    switch (direction)
    {
        case 1:
            if(this->_pos_y - steps==4&&this->_pos_x==2)break;
            else this->_pos_y -= steps;
            break;
        case 2:
            if(this->_pos_y + steps==4&&this->_pos_x==2)break;
            else this->_pos_y += steps;
            break;
        case 3:
            if(this->_pos_x - steps==2&&this->_pos_y==4)break;
            else this->_pos_x -= steps;
            break;
        case 4:
            if(this->_pos_x + steps==2&&this->_pos_y==4)break;
            else this->_pos_x += steps;
            break;
    }
}
