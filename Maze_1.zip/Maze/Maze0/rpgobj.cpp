#include "rpgobj.h"
#include <iostream>

void RPGObj::initObj(string type)
{
    //TODO 所支持的对象类型应定义为枚举
    if (type.compare("player1")==0){
        this->_coverable = false;
        this->_eatable = false;
        this->_vulnerable=true;
    }
    else if(type.compare("player2")==0)
    {
        this->_coverable=false;
        this->_eatable  =false;
        this->_vulnerable=true;
    }
    else if(type.compare("player3")==0)
    {
        this->_coverable=false;
        this->_eatable  =false;
        this->_vulnerable=true;
    }
    else if(type.compare("player4")==0)
    {
        this->_coverable=false;
        this->_eatable  =false;
        this->_vulnerable=true;
    }

    else if(type.compare("spider")==0)
    {
        this->_coverable=false;
        this->_eatable  =false;
        this->_vulnerable=true;
    }
    else if(type.compare("wall")==0)
    {
        this->_coverable=false;
        this->_eatable  =false;
        this->_vulnerable=false;
    }

    else if(type.compare("Kiki1")==0)
    {
        this->_coverable=false;
        this->_eatable  =false;
        this->_vulnerable=true;
    }
    else if(type.compare("Kiki2")==0)
    {
        this->_coverable=false;
        this->_eatable  =false;
        this->_vulnerable=true;
    }
    else if(type.compare("Kiki3")==0)
    {
        this->_coverable=false;
        this->_eatable  =false;
        this->_vulnerable=true;
    }
    else if(type.compare("Kiki4")==0)
    {
        this->_coverable=false;
        this->_eatable  =false;
        this->_vulnerable=true;
    }
    else if(type.compare("Newt1")==0)
    {
        this->_coverable=false;
        this->_eatable  =false;
        this->_vulnerable=true;
    }
    else if(type.compare("Newt2")==0)
    {
        this->_coverable=false;
        this->_eatable  =false;
        this->_vulnerable=true;
    }
    else if(type.compare("Newt3")==0)
    {
        this->_coverable=false;
        this->_eatable  =false;
        this->_vulnerable=true;
    }
    else if(type.compare("Newt4")==0)
    {
        this->_coverable=false;
        this->_eatable  =false;
        this->_vulnerable=true;
    }
    else if(type.compare("Minho1")==0)
    {
        this->_coverable=false;
        this->_eatable  =false;
        this->_vulnerable=true;
    }
    else if(type.compare("Minho2")==0)
    {
        this->_coverable=false;
        this->_eatable  =false;
        this->_vulnerable=true;
    }
    else if(type.compare("Minho3")==0)
    {
        this->_coverable=false;
        this->_eatable  =false;
        this->_vulnerable=true;
    }
    else if(type.compare("Minho4")==0)
    {
        this->_coverable=false;
        this->_eatable  =false;
        this->_vulnerable=true;
    }
    else if(type.compare("Teresa1")==0)
    {
        this->_coverable=false;
        this->_eatable  =false;
        this->_vulnerable=true;
    }
    else if(type.compare("Teresa2")==0)
    {
        this->_coverable=false;
        this->_eatable  =false;
        this->_vulnerable=true;
    }
    else if(type.compare("Teresa3")==0)
    {
        this->_coverable=false;
        this->_eatable  =false;
        this->_vulnerable=true;
    }
    else if(type.compare("Teresa4")==0)
    {
        this->_coverable=false;
        this->_eatable  =false;
        this->_vulnerable=true;
    }
    else
    {
        //TODO 应由专门的错误日志文件记录
        cout<<"invalid ICON type."<<endl;
        return;
    }

    this->_icon = ICON::findICON(type);
    QImage all;
    //TODO文件路径待定

    if(this->_icon.getTypeName()=="player1"||this->_icon.getTypeName()=="player2"||this->_icon.getTypeName()=="player3"||this->_icon.getTypeName()=="player4")
    {
        all.load("D:/images/Thomas.png");
    }
    else if(this->_icon.getTypeName()=="Kiki1"||this->_icon.getTypeName()=="Kiki2"||this->_icon.getTypeName()=="Kiki3"||this->_icon.getTypeName()=="Kiki4")
    {
        all.load("D:/images/Kiki.png");
    }
    else if(this->_icon.getTypeName()=="Newt1"||this->_icon.getTypeName()=="Newt2"||this->_icon.getTypeName()=="Newt3"||this->_icon.getTypeName()=="Newt4")
    {
        all.load("D:/images/Newt.png");
    }
    else if(this->_icon.getTypeName()=="Minho1"||this->_icon.getTypeName()=="Minho2"||this->_icon.getTypeName()=="Minho3"||this->_icon.getTypeName()=="Minho4")
    {
        all.load("D:/images/Minho.png");
    }
    else if(this->_icon.getTypeName()=="Teresa1"||this->_icon.getTypeName()=="Teresa2"||this->_icon.getTypeName()=="Teresa3"||this->_icon.getTypeName()=="Teresa4")
    {
        all.load("D:/images/Teresa.png");
    }



    //else if(this->_icon.getTypeName()=="spider"){ }
   // else if(this->_icon.getTypeName()="wall"){ }



    this->_pic = all.copy(QRect(_icon.getSrcX()*ICON::GRID_SIZE, _icon.getSrcY()*ICON::GRID_SIZE, _icon.getWidth()*ICON::GRID_SIZE, _icon.getHeight()*ICON::GRID_SIZE));
}

void RPGObj::show(QPainter * pa){
    int gSize = ICON::GRID_SIZE;
    pa->drawImage(this->_pos_x*gSize,this->_pos_y*gSize,this->_pic);
}



