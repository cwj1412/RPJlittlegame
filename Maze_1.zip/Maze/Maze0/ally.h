#ifndef ALLY_H
#define ALLY_H
#include "rpgobj.h"


class Ally: public RPGObj
{
public:
    Ally(){}
    ~Ally(){}
    void move(int direction, int steps=1);
    //direction =1,2,3,4 for 上下左右
    int getHP() {return this->HP;}
    int getEXP() {return this->EXP;}
    int getATK() {return this->ATK;}
    int getDEF() {return this->DEF;}

    void updateHP(int num){this->HP+=num;}
    void updateEXP(int num){this->EXP+=num;}
    void updateATK(int num){this->ATK+=num;}
    void updateDEF(int num){this->DEF+=num;}

protected:
    int HP;//生命值
    int EXP;//经验值
    int ATK;//战斗值
    int DEF;//防御值
};


#endif // ALLY_H
