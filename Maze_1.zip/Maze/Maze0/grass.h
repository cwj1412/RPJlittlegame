#ifndef GRASS_H
#define GRASS_H

#include <QDialog>
#include <string>
namespace Ui {
class grass;
}

class grass : public QDialog
{
    Q_OBJECT

public:
    static int step;
    explicit grass(QWidget *parent = 0);
    ~grass();
    void paintEvent(QPaintEvent *);
private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::grass *ui;
};

#endif // GRASS_H
