#ifndef MONSTER_H
#define MONSTER_H
#include "rpgobj.h"


class Monster: public RPGObj
{
public:
    Monster(int initialHP);
    Monster(){}
    ~Monster(){}
    void move(int direction, int steps=1);
    int getHP() {return this->HP;}
    void updateHP(int num){this->HP+=num;}
private:
    int HP;//生命值

};

#endif // MONSTER_H
