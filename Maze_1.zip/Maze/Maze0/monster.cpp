#include <monster.h>
Monster::Monster(int initialHP){
    HP=initialHP;
}
void Monster::move(int direction, int steps)
{
    switch (direction){
        case 1:
            if(this->_pos_y - steps==4&&this->_pos_x==2)break;
            else this->_pos_y -= steps;
            break;
        case 2:
            if(this->_pos_y + steps==4&&this->_pos_x==2)break;
            else this->_pos_y += steps;
            break;
        case 3:
            if(this->_pos_x - steps==2&&this->_pos_y==4)break;
            else this->_pos_x -= steps;
            break;
        case 4:
            if(this->_pos_x + steps==2&&this->_pos_y==4)break;
            else this->_pos_x += steps;
            break;
    }
}
